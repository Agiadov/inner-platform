# INNER — Netlify deploy checklist

## Recommended deploy method
Use GitHub/GitLab connection in Netlify, not a simple static drag-and-drop upload. This project is a Next.js app with API routes (`/api/telegram`, `/api/support`, `/api/rates`), so Netlify needs to build it and create serverless functions.

## Build settings
- Build command: `npm run build`
- Publish directory: leave blank in Netlify UI for Next.js auto-detection
- Node version: 22

`netlify.toml` is included with the build command and Node version.

## Environment variables in Netlify
Add these in Netlify → Project configuration → Environment variables:

Required:
- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`

Recommended:
- `NEXT_PUBLIC_SITE_URL`

Optional:
- `OPENAI_API_KEY`
- `NETLIFY_NEXT_SKEW_PROTECTION=true`

After adding variables, redeploy the site.

## Before deploy
Run locally:

```bash
npm install
npm run build
```

If the build passes locally, push to GitHub and deploy from Netlify.
