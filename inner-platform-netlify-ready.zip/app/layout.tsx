import type { Metadata } from 'next'
import { AISupportButton } from '@/components/inner/ai-support-button'
import './globals.css'

export const metadata: Metadata = {
  title: 'INNER — поиск вещей по фото или ссылке',
  description:
    'INNER помогает найти одежду, аксессуары и компьютерную периферию по фото или ссылке с прозрачной стоимостью до оплаты.',
  generator: 'v0.app',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ru" className="bg-background" suppressHydrationWarning>
      <body className="font-sans antialiased">
        {children}
        <AISupportButton />
      </body>
    </html>
  )
}
